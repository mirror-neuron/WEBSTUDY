package com.test;

public class EmpDTO
{
   private String empno, ename, job, mgr, hiredate, deptno, dname;
   private int sal, comm;
   private String grade;
   
   
   public String getGrade()
   {
      return grade;
   }
   public void setGrade(String grade)
   {
      this.grade = grade;
   }
   public String getEmpno()
   {
      return empno;
   }
   public void setEmpno(String empno)
   {
      this.empno = empno;
   }
   public String getEname()
   {
      return ename;
   }
   public void setEname(String ename)
   {
      this.ename = ename;
   }
   public String getJob()
   {
      return job;
   }
   public void setJob(String job)
   {
      this.job = job;
   }
   public String getMgr()
   {
      return mgr;
   }
   public void setMgr(String mgr)
   {
      this.mgr = mgr;
   }
   public String getHiredate()
   {
      return hiredate;
   }
   public void setHiredate(String hiredate)
   {
      this.hiredate = hiredate;
   }
   public String getDeptno()
   {
      return deptno;
   }
   public void setDeptno(String deptno)
   {
      this.deptno = deptno;
   }
   public int getSal()
   {
      return sal;
   }
   public void setSal(int sal)
   {
      this.sal = sal;
   }
   public String getDname()
   {
      return dname;
   }
   public void setDname(String dname)
   {
      this.dname = dname;
   }
   public int getComm()
   {
      return comm;
   }
   public void setComm(int comm)
   {
      this.comm = comm;
   }

   
   
   
}