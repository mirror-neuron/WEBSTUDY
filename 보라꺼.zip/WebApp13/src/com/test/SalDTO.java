package com.test;

public class SalDTO
{
	// 주요 속성 구성(프로퍼티 구성)
	private String grade;
	private int losal, hisal;
	
	// getter / setter 구성
	public String getGrade()
	{
		return grade;
	}
	public void setGrade(String grade)
	{
		this.grade = grade;
	}
	public int getLosal()
	{
		return losal;
	}
	public void setLosal(int losal)
	{
		this.losal = losal;
	}
	public int getHisal()
	{
		return hisal;
	}
	public void setHisal(int hisal)
	{
		this.hisal = hisal;
	}


}
